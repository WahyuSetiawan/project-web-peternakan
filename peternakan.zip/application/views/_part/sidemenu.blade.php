<div class="menu">
    <div class="title">
        <a href="{{base_url()}}">Dashboard</a>
    </div>
</div>
<div class="menu">
    <div class="title">
        <a href=""><span class="fa fa-bookmark"></span> Data Peternakan <i class="fa fa-caret-down"></i></a>
    </div>

    <div class="submenu">
        @if ($head['type'] == 'karyawan')
        <a href="{{base_url('kandang')}}"> <i class="fa fa-tags"></i> Kandang</a>
        <a href="{{base_url('supplier')}}"><i class="fa fa-group"></i> Supplier</a>
        <a href="{{base_url('gudang')}}"><i class="fa fa-truck"></i> Pakan</a>
        <a href="{{base_url('jadwalpersediaan')}}"><i class="fa fa-calendar-o"></i> Jadwal Pakan</a>
        @endif
        @if ($head['type'] == 'admin')
        <a href="{{base_url('karyawan')}}"><i class="fa fa-address-card"></i> Karyawan </a>
        @endif
    </div>
</div>

@if ($head['type'] == 'karyawan')
<div class="menu">
    <div class="title">
        <a href=""><i class="fa fa-database"></i> Transaksi</a>
    </div>

    <div class="submenu">
        <a href="{{base_url('kandang/pembelian')}}"><i class="fa fa-shopping-basket"></i> Pembelian Ayam</a>
        <a href="{{base_url('kandang/penjualan')}}"><i class="fa fa-industry"></i> Penjualan Ayam</a>
        <a href="{{base_url('kandang/kerugian')}}"><i class="fa fa-industry"></i> Kerugian Ayam</a>
        <a href="{{base_url('gudang/pembelian')}}"><i class="fa fa-shopping-basket"></i> Pembelian Pakan</a>
        <a href="{{base_url('gudang/penggunaan')}}"><i class="fa fa-signing"></i> Pemberian Pakan</a>
    </div>
</div>
<div class="menu">
    <div class="title">
        <a href=""><i class="fa fa-inbox"></i> Data Kandang</a>
    </div>

    <div class="submenu">
        <a href="{{base_url('riwayat/group')}}"><i class="fa fa-inbox"></i> Riwayat Penjualan</a>
        <a href="{{base_url('stokkandang')}}"><i class="fa fa-inbox"></i> Stok Ayam</a>
        <a href="{{base_url('stokgudang')}}"><i class="fa fa-inbox"></i> Stok Pakan</a>
    </div>
</div>

@endif
<?php

if ($head['type'] == "admin") { ?>
    <div class="menu">
        <div class="title">
            <a href=""><i class="fa fa-file-o"></i> Laporan</a>
        </div>

        <div class="submenu">
            <a href="{{base_url('laporan/stokayam')}}"><i class="fa fa-file-o"></i> Ayam</a>
            <a href="{{base_url('laporan/stokgudang')}}"><i class="fa fa-file-o"></i> Pakan</a>
            <a href="{{base_url('laporan/jadwalpakan')}}"><i class="fa fa-file-o"></i> Jadwal Pakan</a>
            <a href="{{base_url('laporan/penggunaanGudang')}}"><i class="fa fa-file-o"></i> Penggunaan Pakan</a>
            <a href="{{base_url('laporan/transaksigudang')}}"><i class="fa fa-file-o"></i> Laporan Pakan</a>
            <a href="{{base_url('laporan/transaksiayam')}}"><i class="fa fa-file-o"></i> Laporan Ayam</a>
            <a href="{{base_url('laporan/group')}}"><i class="fa fa-file-o"></i> Laporan Pendapatan</a>
        </div>
    </div>

    <div class="menu">
        <div class="title">
            <a href=""><i class="fa fa-gear"></i> Setting</a>
        </div>

        <div class="submenu">
            <a href="{{base_url('admin')}}">Admin</a>
        </div>
    </div>
<?php } else { ?>
    <div class="menu">
        <div class="title">
            <a href=""><i class="fa fa-gear"></i> Setting</a>
        </div>

        <div class="submenu">
            <a href="{{base_url('karyawan')}}">Karyawan</a>
        </div>
    </div>
<?php } ?>