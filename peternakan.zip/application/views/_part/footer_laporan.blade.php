<div style="margin-top: 20px;align-content: flex-end" align="right">
    <div align="center" style="width: 250px">
        <div>Tanggal : <?php echo Date("Y-m-d")?></div>
        <div style="margin-top:10px">Penanggung Jawab</div>
        <div style="margin-top: 100px">
            <tbody>
                <tr>
                    <td style="height:100px;text-align: center; vertical-align: bottom">
                        (_______________)
                    </td>
                </tr>
            </tbody>
        </div>
    </div>
</div>