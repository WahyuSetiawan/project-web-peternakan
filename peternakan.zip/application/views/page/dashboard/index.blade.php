@extends('_part/layout', $head)

@section('content')
{{-- @if ($head['type'] == "karyawan")
@include('page.dashboard.welcomekaryawan')
@elseif ($head['type'] == "admin")
@include('page.dashboard.welcomeadmin')
@endif --}}
@endsection