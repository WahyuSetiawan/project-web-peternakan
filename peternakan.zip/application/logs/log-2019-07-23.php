<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-23 20:04:14 --> Severity: Warning --> mysqli::real_connect(): (42000/1049): Unknown database 'peternakan_app' /usr/share/httpd/www/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-07-23 20:04:14 --> Unable to connect to the database
ERROR - 2019-07-23 20:04:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-23 20:49:53 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-23 20:50:51 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-23 22:31:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-23 22:47:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-23 22:49:42 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-23 23:07:12 --> Severity: Notice --> Undefined index: id_detail_pembelian_ayam /usr/share/httpd/www/application/controllers/Kandang.php 332
ERROR - 2019-07-23 23:07:12 --> Severity: Notice --> Undefined index: id_detail_pembelian_ayam /usr/share/httpd/www/application/controllers/Kandang.php 333
ERROR - 2019-07-23 23:07:12 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 199
ERROR - 2019-07-23 23:07:43 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 199
ERROR - 2019-07-23 23:08:09 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 199
ERROR - 2019-07-23 23:08:45 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 51
ERROR - 2019-07-23 23:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 51
ERROR - 2019-07-23 23:08:45 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:08:53 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:09:26 --> Severity: Notice --> Undefined property: stdClass::$stok /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 54
ERROR - 2019-07-23 23:09:26 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:09:56 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:10:01 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:11:14 --> Severity: Notice --> Undefined variable: kandang_stok /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:11:46 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 51
ERROR - 2019-07-23 23:11:46 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 51
ERROR - 2019-07-23 23:12:35 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS), expecting variable (T_VARIABLE) or '$' /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:12:53 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS), expecting variable (T_VARIABLE) or '$' /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 213
ERROR - 2019-07-23 23:13:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 54
ERROR - 2019-07-23 23:13:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 54
ERROR - 2019-07-23 23:13:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 54
ERROR - 2019-07-23 23:13:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 54
ERROR - 2019-07-23 23:40:10 --> Query error: Unknown column 'view_stok_ayam.siap_jual' in 'where clause' - Invalid query: SELECT *
FROM `view_stok_ayam`
WHERE `view_stok_ayam`.`siap_jual` > 120
AND `view_stok_ayam`.`jumlah` >0
ERROR - 2019-07-23 23:40:39 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-23 23:40:40 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-23 23:44:46 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-23 23:44:53 --> 404 Page Not Found: Asset/css
