<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-26 00:20:22 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-26 01:02:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 01:02:25 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:02:25 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:02:25 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:02:25 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:07:54 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:07:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:07:54 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:07:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:08:44 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:08:44 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:08:44 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:09:51 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:09:51 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:09:51 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:09:51 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:09:54 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:09:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:09:54 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:09:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:23 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:23 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:25 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:25 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:25 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:25 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:33 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:33 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:35 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:10:35 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:11:17 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:11:17 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:11:17 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:11:17 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:11:36 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:11:36 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:12:18 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:12:18 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:12:45 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:12:45 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:13:00 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:13:00 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:13:13 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:13:13 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:38 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:38 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:47 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:47 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:57 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:14:57 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:06 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:06 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:06 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:06 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:11 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:11 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:22 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:22 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:38 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:15:38 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-26 01:16:04 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:18:03 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:18:03 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:18:03 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:18:03 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:18:03 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:24:28 --> Severity: Notice --> Array to string conversion /usr/share/httpd/www/system/database/DB_query_builder.php 683
ERROR - 2019-07-26 01:24:28 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tb_supplier`
WHERE `id_supplier` = `Array`
ERROR - 2019-07-26 01:25:42 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:25:42 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:25:42 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:25:42 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:25:42 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:26:06 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:06 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:26:06 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:26:06 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:26:06 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:26:06 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:41 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:26:41 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 92
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 95
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 92
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 95
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 92
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 95
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 98
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-26 01:26:41 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-26 01:26:56 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:56 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:26:56 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:26:56 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:27:19 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:27:19 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:28:55 --> Query error: Unknown table 'supplier' - Invalid query: SELECT DISTINCT `supplier`.*
FROM `tb_supplier`
INNER JOIN `tb_detail_pembelian_ayam` ON `tb_detail_pembelian_ayam`.`id_supplier` = `tb_supplier`.`id_supplier`
WHERE `tb_detail_pembelian_ayam`.`id_detail_group_transaksi` = 'GT_0003'
ERROR - 2019-07-26 01:29:09 --> Query error: Unknown column 'supplier.id_supplier' in 'field list' - Invalid query: SELECT DISTINCT `supplier`.`id_supplier`
FROM `tb_supplier`
INNER JOIN `tb_detail_pembelian_ayam` ON `tb_detail_pembelian_ayam`.`id_supplier` = `tb_supplier`.`id_supplier`
WHERE `tb_detail_pembelian_ayam`.`id_detail_group_transaksi` = 'GT_0003'
ERROR - 2019-07-26 01:29:14 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:29:14 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:29:42 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-26 01:29:42 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-26 01:31:29 --> Severity: Error --> Access to undeclared static property: ViewDetailGroupTransaksi::$table /usr/share/httpd/www/application/models/ViewDetailGroupTransaksi.php 19
ERROR - 2019-07-26 01:34:18 --> Query error: Unknown column 'view_detail_group_transaksi.id_kasdfandang' in 'where clause' - Invalid query: SELECT `view_detail_group_transaksi`.*
FROM `view_detail_group_transaksi`
WHERE `view_detail_group_transaksi`.`id_kasdfandang` = 'KD_0001'
ERROR - 2019-07-26 01:35:33 --> Query error: Unknown column 'view_detail_group_transaksi.id_supplier' in 'where clause' - Invalid query: SELECT `view_detail_group_transaksi`.*
FROM `view_detail_group_transaksi`
WHERE `view_detail_group_transaksi`.`id_supplier` = 'SP_0002'
AND `view_detail_group_transaksi`.`id_kandang` = 'KD_0001'
ERROR - 2019-07-26 02:20:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 02:20:06 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 02:20:06 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 02:39:45 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 02:40:00 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/1d5586b588c77480cceed91168805b80 22
ERROR - 2019-07-26 02:40:00 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1d5586b588c77480cceed91168805b80 22
ERROR - 2019-07-26 02:40:04 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/1d5586b588c77480cceed91168805b80 22
ERROR - 2019-07-26 02:40:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1d5586b588c77480cceed91168805b80 22
ERROR - 2019-07-26 02:40:12 --> Query error: Unknown column 'tb_detail_penjualan_ayam.id_detail_pembelian_ayam' in 'where clause' - Invalid query: SELECT `tb_detail_penjualan_ayam`.*, `tb_kandang`.`nama` as `nama_kandang`, DATE_FORMAT(tb_detail_penjualan_ayam.tanggal, "%d-%m-%Y") as tanggal, `tb_karyawan`.`nama` as `nama_karyawan`, `tb_admin`.`nama` as `nama_admin`, `harga`, `admin_update`.`nama` as `update_by_admin_nama`, `karyawan_update`.`nama` as `update_by_karyawan_nama`
FROM `tb_detail_penjualan_ayam`
LEFT JOIN `tb_detail_pembelian_ayam` ON `tb_detail_pembelian_ayam`.`id_detail_pembelian_ayam` = `tb_detail_penjualan_ayam`.`id_detail_pembelian_ayam`
LEFT JOIN `tb_kandang` ON `tb_kandang`.`id_kandang` = `tb_detail_penjualan_ayam`.`id_kandang`
LEFT JOIN `tb_karyawan` ON `tb_karyawan`.`id_karyawan` = `tb_detail_penjualan_ayam`.`id_karyawan`
LEFT JOIN `tb_admin` ON `tb_admin`.`id` = `tb_detail_penjualan_ayam`.`id_admin`
LEFT JOIN `tb_admin` as `admin_update` ON `admin_update`.`id` = `tb_detail_penjualan_ayam`.`update_by_admin`
LEFT JOIN `tb_karyawan` as `karyawan_update` ON `karyawan_update`.`id_karyawan` = `tb_detail_penjualan_ayam`.`update_by_karyawan`
WHERE `tb_detail_penjualan_ayam`.`id_detail_pembelian_ayam` = 'MA_0001'
ERROR - 2019-07-26 02:40:22 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-26 02:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-26 02:40:29 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/dc26a12fc0ff2134e9b5eb3af188638b 44
ERROR - 2019-07-26 02:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/dc26a12fc0ff2134e9b5eb3af188638b 44
ERROR - 2019-07-26 07:54:09 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 08:38:11 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-26 08:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-26 08:41:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_transksi_keluar /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 185
ERROR - 2019-07-26 08:41:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_transksi_keluar /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 185
ERROR - 2019-07-26 08:41:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_transksi_keluar /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 185
ERROR - 2019-07-26 08:41:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_transksi_keluar /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 185
ERROR - 2019-07-26 17:41:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 17:41:09 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 17:41:25 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 17:43:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 17:44:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 17:44:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 17:44:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 20:09:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 20:09:09 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 20:14:18 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-26 20:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-26 20:16:23 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-26 20:16:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-26 20:18:23 --> Severity: error --> Exception: View [page.riwayat.page_group_pembelian_laporan] not found. /usr/share/httpd/www/application/vendor/xiaoler/blade/src/FileViewFinder.php 135
ERROR - 2019-07-26 20:18:33 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
ERROR - 2019-07-26 20:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
ERROR - 2019-07-26 20:18:56 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
ERROR - 2019-07-26 20:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
ERROR - 2019-07-26 22:32:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-26 22:32:19 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-26 22:33:09 --> Severity: error --> Exception: View [page.laporan.laporan_page] not found. /usr/share/httpd/www/application/vendor/xiaoler/blade/src/FileViewFinder.php 135
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined variable: title /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 1
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:33:23 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 35
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 38
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 46
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 49
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 52
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 56
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 59
ERROR - 2019-07-26 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 61
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:10 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:27 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 34
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 22:55:28 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:10 --> Severity: Compile Error --> Cannot redeclare class ViewDetailGroupTransaksi /usr/share/httpd/www/application/models/ViewDetailGroupTransaksiAyamModel.php 56
ERROR - 2019-07-26 23:07:42 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:42 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:07:43 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:04 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:05 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:05 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:05 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:07 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:08 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:09 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 37
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$supplier /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 40
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 48
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 51
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 54
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 57
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 60
ERROR - 2019-07-26 23:08:10 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/96c4f29f96742f626b1f5aa0cfd3c38b 63
ERROR - 2019-07-26 23:08:19 --> Severity: Notice --> Undefined variable: transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 88
ERROR - 2019-07-26 23:08:19 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 88
ERROR - 2019-07-26 23:08:22 --> Severity: Notice --> Undefined variable: transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 88
ERROR - 2019-07-26 23:08:22 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 88
ERROR - 2019-07-26 23:08:46 --> Severity: Notice --> Undefined variable: transaksi /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 23:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 32
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:08:52 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 37
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:49 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:10:55 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:50 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:11:54 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:12:16 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:14:47 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$nama_karyawan /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 42
ERROR - 2019-07-26 23:15:01 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:16:14 --> Severity: Notice --> Undefined property: stdClass::$update_by_karyawan_nama /usr/share/httpd/www/application/cache/views/7054f7cc5e2025be72d09785527faf3e 57
ERROR - 2019-07-26 23:20:49 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
ERROR - 2019-07-26 23:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/90e8b27e075f77a8902da5e3b135e9de 18
