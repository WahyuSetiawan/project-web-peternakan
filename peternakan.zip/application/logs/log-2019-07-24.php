<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-24 00:22:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 00:22:00 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-24 00:42:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 00:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 00:47:58 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 407
ERROR - 2019-07-24 00:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 00:48:31 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 407
ERROR - 2019-07-24 00:48:31 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 412
ERROR - 2019-07-24 00:48:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 00:48:41 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 407
ERROR - 2019-07-24 00:48:41 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 412
ERROR - 2019-07-24 00:49:14 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:49:26 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:50:09 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:50:36 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 407
ERROR - 2019-07-24 00:50:36 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:50:43 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:51:23 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:51:33 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:51:45 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:52:16 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:52:25 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:52:53 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Kandang.php 409
ERROR - 2019-07-24 00:52:59 --> Query error: Unknown column 'view_stok_ayam.id_kandangs' in 'where clause' - Invalid query: SELECT *
FROM `view_stok_ayam`
WHERE `view_stok_ayam`.`umur_ayam_sekarang` > 120
AND `view_stok_ayam`.`jumlah` >0
AND `view_stok_ayam`.`id_kandangs` = 'KD_0001'
ERROR - 2019-07-24 00:53:11 --> Severity: Error --> Cannot use object of type stdClass as array /usr/share/httpd/www/application/controllers/Kandang.php 407
ERROR - 2019-07-24 01:02:48 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 7
ERROR - 2019-07-24 01:02:48 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 40
ERROR - 2019-07-24 01:03:22 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 7
ERROR - 2019-07-24 01:20:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 01:20:15 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-24 01:37:56 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:37:56 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 19
ERROR - 2019-07-24 01:37:56 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 138
ERROR - 2019-07-24 01:38:30 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:38:30 --> Severity: Notice --> Undefined variable: id_pembelian /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 144
ERROR - 2019-07-24 01:39:27 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:40:06 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:40:06 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:06 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:06 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:29 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 561
ERROR - 2019-07-24 01:40:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah /usr/share/httpd/www/application/cache/views/c31fc436c4dac987ca996cbfd9957e77 146
ERROR - 2019-07-24 01:40:44 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 561
ERROR - 2019-07-24 01:40:58 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:42:48 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:43:55 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 01:46:45 --> Severity: Notice --> Undefined index: pembelian /usr/share/httpd/www/application/controllers/Kandang.php 559
ERROR - 2019-07-24 02:36:57 --> Query error: View 'peternakan_app.view_stok_ayam' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them - Invalid query: SELECT *
FROM `view_stok_ayam`
WHERE `view_stok_ayam`.`sisa_jumlah_ayam` >0
ERROR - 2019-07-24 02:39:22 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', 'SP_0001', '10', '20', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:42:10 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `id_detail_group_transaksi`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', 'SP_0001', '10', '', '20', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:46:11 --> Query error: Unknown column 'id_detail_group_transaksi' in 'field list' - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `id_detail_group_transaksi`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', 'SP_0001', '10', '', '20', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:46:20 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', 'SP_0001', '10', '20', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:46:51 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `umur`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', '10', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:46:59 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `umur`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', '10', '2019-07-24', '100')
ERROR - 2019-07-24 02:47:07 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `umur`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', '10', '100')
ERROR - 2019-07-24 02:52:03 --> Query error: Unknown column 'id_detail_group_transaksi' in 'field list' - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `id_detail_group_transaksi`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0002', 'SP_0001', '10', '', '20', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:55:29 --> Query error: Table 'peternakan_app.inserted' doesn't exist - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `id_detail_group_transaksi`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0001', 'SP_0001', '100', NULL, '1000', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 02:57:09 --> Query error: Table 'peternakan_app.NEW' doesn't exist - Invalid query: INSERT INTO `tb_detail_pembelian_ayam` (`id_detail_pembelian_ayam`, `id_kandang`, `id_supplier`, `umur`, `id_detail_group_transaksi`, `harga_ayam`, `id_karyawan`, `id_admin`, `tanggal`, `jumlah_ayam`) VALUES ('MA_0002', 'KD_0001', 'SP_0001', '100', NULL, '1000', 'KR_0001', NULL, '2019-07-24', '100')
ERROR - 2019-07-24 03:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 03:14:18 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 03:14:18 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 03:14:18 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 03:14:39 --> Query error: Unknown column 'id_detail_group_tansaksi' in 'field list' - Invalid query: SELECT `tb_detail_pembelian_ayam`.*, `tb_kandang`.`nama` as `nama_kandang`, DATE_FORMAT(tb_detail_pembelian_ayam.tanggal, "%d-%m-%Y") as tanggal, `tb_karyawan`.`nama` as `nama_karyawan`, `tb_supplier`.`nama` as `nama_supplier`, `tb_admin`.`nama` as `nama_admin`, `admin_update`.`nama` as `update_by_admin_nama`, `id_detail_group_tansaksi`, `jumlah_sisa_ayam`, `jumlah_penjualan`, `umur_ayam_sekarang`, `jumlah_penjualan_harga`, `jumlah_kerugian_ayam`, (jumlah_penjualan_harga- harga_ayam) as harga_sisa, `karyawan_update`.`nama` as `update_by_karyawan_nama`
FROM `tb_detail_pembelian_ayam`
INNER JOIN `tb_supplier` ON `tb_supplier`.`id_supplier` = `tb_detail_pembelian_ayam`.`id_supplier`
LEFT JOIN `tb_karyawan` ON `tb_karyawan`.`id_karyawan` =`tb_detail_pembelian_ayam`.`id_karyawan`
LEFT JOIN `tb_kandang` ON `tb_kandang`.`id_kandang` = `tb_detail_pembelian_ayam`.`id_kandang`
LEFT JOIN `tb_admin` ON `tb_admin`.`id` = `tb_detail_pembelian_ayam`.`id_admin`
LEFT JOIN `tb_admin` as `admin_update` ON `admin_update`.`id` = `tb_detail_pembelian_ayam`.`update_by_admin`
LEFT JOIN `tb_karyawan` as `karyawan_update` ON `karyawan_update`.`id_karyawan` = `tb_detail_pembelian_ayam`.`id_karyawan`
INNER JOIN `view_sisa_pembelian` ON `view_sisa_pembelian`.`id_detail_pembelian_ayam` = `tb_detail_pembelian_ayam`.`id_detail_pembelian_ayam`
ERROR - 2019-07-24 03:15:06 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 03:15:06 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 03:15:06 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_tansaksi /usr/share/httpd/www/application/cache/views/2ffcdabd32f6a1d39d8efbed2f9fc43d 90
ERROR - 2019-07-24 08:50:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 08:50:53 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-24 18:49:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 18:49:46 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-24 18:51:34 --> Severity: Notice --> Undefined property: stdClass::$id_detail_group_transksi /usr/share/httpd/www/application/cache/views/cc9a544cd29d279425f54e5b523cf476 217
ERROR - 2019-07-24 21:35:07 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-24 21:35:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 21:48:31 --> Severity: Notice --> Array to string conversion /usr/share/httpd/www/application/controllers/Kandang.php 405
ERROR - 2019-07-24 21:56:31 --> Query error: Duplicate entry 'KD_0001' for key 'id_kandang' - Invalid query: INSERT INTO `tb_detail_kerugian_ayam` (`id_detail_kerugian_ayam`, `tanggal`, `id_detail_group_transaksi`, `keterangan`, `jumlah`, `id_kandang`, `id_karyawan`, `id_admin`) VALUES ('KA_0002', '2019-07-24', 'GT_0001', '', '10', 'KD_0001', 'KR_0001', NULL)
ERROR - 2019-07-24 21:58:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 22:40:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 22:40:53 --> Severity: Notice --> Undefined index: id_pembelian /usr/share/httpd/www/application/controllers/Kandang.php 453
ERROR - 2019-07-24 22:41:14 --> Severity: Notice --> Undefined index: id_pembelian /usr/share/httpd/www/application/controllers/Kandang.php 453
ERROR - 2019-07-24 22:42:28 --> Severity: Error --> Call to undefined method stdClass::row() /usr/share/httpd/www/application/controllers/Kandang.php 492
ERROR - 2019-07-24 22:42:38 --> Severity: Notice --> Undefined property: stdClass::$result /usr/share/httpd/www/application/controllers/Kandang.php 492
ERROR - 2019-07-24 22:47:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-24 22:51:27 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-24 22:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-24 22:51:42 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/9f3fe66d8cb8a3c6fdcfd756d24ff74f 62
ERROR - 2019-07-24 22:51:42 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/9f3fe66d8cb8a3c6fdcfd756d24ff74f 62
ERROR - 2019-07-24 23:26:04 --> Severity: Error --> Call to undefined method ViewStokAyamModel::countAll() /usr/share/httpd/www/application/controllers/Riwayat.php 44
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:28:29 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:28:30 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 84
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 87
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 90
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 93
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 96
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 99
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 102
ERROR - 2019-07-24 23:29:37 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/75ee642ec3dd76cf8caeb17c6b8c499a 106
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_group_transaksi /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_group_transaksi /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_group_transaksi /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 84
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:45 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$nama_supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:29:58 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 87
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:30:27 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 106
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 88
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 91
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 94
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 97
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 103
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 88
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 91
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 94
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 97
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 103
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 88
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 91
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 94
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 97
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 103
ERROR - 2019-07-24 23:36:11 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 107
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:36:22 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$created_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$updated_at /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:41:55 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:42:58 --> Query error: Unknown column 'view_detail_group_transaksi.id_karyawan' in 'on clause' - Invalid query: SELECT `view_detail_group_transaksi`.*
FROM `view_detail_group_transaksi`
LEFT JOIN `tb_karyawan` ON `tb_karyawan`.`id_karyawan` = `view_detail_group_transaksi`.`id_karyawan`
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:43:20 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan_harga /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$harga_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 102
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:43:38 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:45:14 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:45:14 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:45:14 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:45:14 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:50:48 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:50:48 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:50:48 --> Severity: Notice --> Undefined property: stdClass::$jumlah_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 105
ERROR - 2019-07-24 23:50:48 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:51:11 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:51:11 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 109
ERROR - 2019-07-24 23:52:17 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 111
ERROR - 2019-07-24 23:52:17 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 111
ERROR - 2019-07-24 23:52:31 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 111
ERROR - 2019-07-24 23:52:31 --> Severity: Notice --> Undefined property: stdClass::$id_detail_pembelian_ayam /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 111
ERROR - 2019-07-24 23:59:23 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row /usr/share/httpd/www/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-24 23:59:23 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `view_detail_group_transaksi`.*
FROM `view_detail_group_transaksi`
ERROR - 2019-07-24 23:59:39 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row /usr/share/httpd/www/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-24 23:59:39 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `view_detail_group_transaksi`.*
FROM `view_detail_group_transaksi`
