<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-02 09:30:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:30:39 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:30:46 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:30:50 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:30:55 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:31:02 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:31:09 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-02 09:31:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:32:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:32:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:33:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:35:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:35:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:36:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:39:29 --> Query error: Duplicate entry 'JK_0007' for key 'PRIMARY' - Invalid query: INSERT INTO `tb_detail_penggunaan_gudang` (`id_detail_penggunaan_gudang`, `id_gudang`, `id_karyawan`, `id_kandang`, `id_admin`, `tanggal`, `jumlah`, `keterangan`) VALUES ('JK_0007', 'Jagung', 'KR_0001', 'kandang ayam 1', NULL, '2019-07-02', '10', NULL)
ERROR - 2019-07-02 09:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:55:13 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:13 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:13 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 09:55:22 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:22 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:22 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 09:55:49 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:15 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:15 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:15 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:20 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:20 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:20 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:21 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:22 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:22 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:23 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:23 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:23 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:24 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:24 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:24 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:25 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:25 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:08:26 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:16:35 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-02 10:16:55 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:16:55 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:16:55 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:17:01 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:17:27 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:17:28 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:17:28 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:17:34 --> 404 Page Not Found: Asset/fonts
ERROR - 2019-07-02 10:20:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 10:23:59 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-02 10:33:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id_gudang`, `tb_gudang`.`nama`
FROM `tb_jadwal_kandang`
LEFT JOIN `tb_kandang`' at line 1 - Invalid query: SELECT `Distinct` `tb_jadwal_kandang`.`id_gudang`, `tb_gudang`.`nama`
FROM `tb_jadwal_kandang`
LEFT JOIN `tb_kandang` ON `tb_kandang`.`id_kandang` = `tb_jadwal_kandang`.`id_kandang`
LEFT JOIN `tb_gudang` ON `tb_gudang`.`id_gudang` = `tb_jadwal_kandang`.`id_gudang`
WHERE `tb_jadwal_kandang`.`hari` = date_format('2019-07-02 10:33','%w')
ERROR - 2019-07-02 10:34:03 --> Severity: Notice --> Undefined property: stdClass::$id_gudang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 70
ERROR - 2019-07-02 10:34:03 --> Severity: Notice --> Undefined property: stdClass::$id_gudang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 70
ERROR - 2019-07-02 10:34:03 --> Severity: Notice --> Undefined property: stdClass::$id_gudang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 208
ERROR - 2019-07-02 10:34:57 --> Severity: Notice --> Undefined property: Gudang::$SupplierModel /usr/share/httpd/www/application/controllers/Gudang.php 608
ERROR - 2019-07-02 10:34:57 --> Severity: Error --> Call to a member function get() on a non-object /usr/share/httpd/www/application/controllers/Gudang.php 608
ERROR - 2019-07-02 12:09:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 12:17:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 12:23:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 12:24:27 --> Query error: Unknown column 'id_kandang' in 'field list' - Invalid query: INSERT INTO `tb_detail_kerugian_ayam` (`id_detail_kerugian_ayam`, `tanggal`, `id_detail_pembelian_ayam`, `keterangan`, `jumlah`, `id_kandang`, `id_karyawan`, `id_admin`) VALUES ('KA_0004', '2019-07-02', 'MA_0021', '', '10', 'KD_0003', 'KR_0001', NULL)
ERROR - 2019-07-02 13:25:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 13:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 14:24:54 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-02 14:24:58 --> 404 Page Not Found: Asset/css
