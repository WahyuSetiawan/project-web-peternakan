<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-22 00:50:21 --> 404 Page Not Found: Faviconico/index
