<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-10 06:53:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:53:30 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-10 06:53:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:53:45 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-10 06:53:45 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-10 06:53:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:55:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:56:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:56:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:57:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 06:57:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 07:28:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 07:44:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 07:44:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 08:54:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 08:57:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:21:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:21:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:22:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:22:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:29:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:30:02 --> Severity: Notice --> Undefined property: stdClass::$waktu_mulai_view /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 208
ERROR - 2019-07-10 09:30:02 --> Severity: Notice --> Undefined property: stdClass::$waktu_selesai_view /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 208
ERROR - 2019-07-10 09:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:31:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:32:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 09:32:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:14:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:38:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:38:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:40:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:40:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:40:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 11:49:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 12:05:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 12:08:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 12:09:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 12:37:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 13:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-10 13:23:42 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:42 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:42 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-10 13:23:47 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:47 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:48 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-10 13:23:51 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:51 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-10 13:23:51 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-10 13:24:00 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:31 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:33 --> Severity: Notice --> Undefined property: Laporan::$pdfGenerator /usr/share/httpd/www/application/controllers/Laporan.php 164
ERROR - 2019-07-10 13:24:33 --> Severity: Error --> Call to a member function generate() on a non-object /usr/share/httpd/www/application/controllers/Laporan.php 164
ERROR - 2019-07-10 13:24:37 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:37 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:47 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:25:23 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:25:23 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:25:43 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:25:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:26:08 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:26:15 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:26:28 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:33 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:34 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:37 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:40 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:43 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:45 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:47 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:26:50 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-10 13:32:07 --> Severity: Warning --> date() expects at least 1 parameter, 0 given /usr/share/httpd/www/application/cache/views/983d56dc1004261223a90a2c8dcc964c 4
ERROR - 2019-07-10 13:38:09 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/dc26a12fc0ff2134e9b5eb3af188638b 44
ERROR - 2019-07-10 13:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/dc26a12fc0ff2134e9b5eb3af188638b 44
ERROR - 2019-07-10 13:38:16 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/62f13e3afc85646df296344e7169ff71 36
ERROR - 2019-07-10 13:39:15 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/62f13e3afc85646df296344e7169ff71 36
ERROR - 2019-07-10 13:40:31 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/62f13e3afc85646df296344e7169ff71 36
ERROR - 2019-07-10 13:41:44 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/62f13e3afc85646df296344e7169ff71 36
ERROR - 2019-07-10 13:45:34 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:45:34 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:45:35 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/72e0bae86549cc73a58fc9b84ef07256 32
ERROR - 2019-07-10 13:45:37 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:45:39 --> Severity: Parsing Error --> syntax error, unexpected '[' /usr/share/httpd/www/application/cache/views/72e0bae86549cc73a58fc9b84ef07256 32
ERROR - 2019-07-10 13:46:07 --> Severity: Notice --> Undefined variable: bulan /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:46:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/1eef8e278e4874d1e2f3f3d77731da2b 41
ERROR - 2019-07-10 13:46:10 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:46:14 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:46:14 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:46:30 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/b4fe1b4379ddaca4eed9e73587db4192 23
ERROR - 2019-07-10 13:46:53 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:47:06 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:47:07 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:47:41 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
ERROR - 2019-07-10 13:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/8b2d954d85a84849bb7a16a1f6c887ae 23
