<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-25 03:09:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-25 03:09:42 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-25 03:21:47 --> 404 Page Not Found: Riwayat/pembelian
ERROR - 2019-07-25 04:20:41 --> 404 Page Not Found: Riwayat/pembelian
ERROR - 2019-07-25 04:25:55 --> Severity: Notice --> Undefined property: Riwayat::$viewDetailPembelianAyam /usr/share/httpd/www/application/controllers/Riwayat.php 93
ERROR - 2019-07-25 04:25:55 --> Severity: Error --> Call to a member function countAll() on a non-object /usr/share/httpd/www/application/controllers/Riwayat.php 93
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 101
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 101
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 90
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 93
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 96
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_pembelian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 99
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_penjualan /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 100
ERROR - 2019-07-25 04:26:39 --> Severity: Notice --> Undefined property: stdClass::$jumlah_ayam_kerugian /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 101
ERROR - 2019-07-25 04:28:02 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:28:02 --> Severity: Notice --> Undefined variable: kandang_stok /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:28:54 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:28:54 --> Severity: Notice --> Undefined variable: kandang_stok /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:29:29 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:29:29 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:29:29 --> Severity: Notice --> Undefined variable: kandang_stok /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:29:29 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 187
ERROR - 2019-07-25 04:29:51 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:30:20 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:30:20 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:30:58 --> Severity: Notice --> Undefined variable: id_group /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 6
ERROR - 2019-07-25 04:30:58 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:30:58 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:31:28 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:31:28 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:32:15 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:32:15 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:32:20 --> Severity: Notice --> Undefined property: Riwayat::$detalPenjualanAyamModel /usr/share/httpd/www/application/controllers/Riwayat.php 142
ERROR - 2019-07-25 04:32:20 --> Severity: Error --> Call to a member function countAll() on a non-object /usr/share/httpd/www/application/controllers/Riwayat.php 142
ERROR - 2019-07-25 04:32:47 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 54
ERROR - 2019-07-25 04:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 54
ERROR - 2019-07-25 04:33:10 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 54
ERROR - 2019-07-25 04:33:10 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 54
ERROR - 2019-07-25 04:34:14 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 22
ERROR - 2019-07-25 04:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 22
ERROR - 2019-07-25 04:35:43 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 22
ERROR - 2019-07-25 04:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/c6c37f1304ab8041932e3ccc7c731a0e 22
ERROR - 2019-07-25 04:35:52 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:35:52 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:36:27 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:36:27 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:36:30 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:36:30 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/10f351845f354179ce7def4c43fd7c60 17
ERROR - 2019-07-25 04:38:56 --> Severity: Notice --> Undefined variable: kandang /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-25 04:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 20
ERROR - 2019-07-25 04:38:56 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-25 04:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/a34ef74917026fd40e9cdbbe912cbe7d 33
ERROR - 2019-07-25 04:38:58 --> Severity: Notice --> Undefined variable: semua_kandang /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 04:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/0f81358c94ebd873799c38f999281c3c 18
ERROR - 2019-07-25 08:45:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-25 08:45:27 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-25 08:45:32 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-25 21:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-25 21:07:28 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-25 22:43:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-25 23:17:40 --> 404 Page Not Found: Faviconico/index
