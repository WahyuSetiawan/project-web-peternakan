<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-11 09:18:54 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-11 10:40:21 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-11 11:08:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-11 11:09:00 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-11 13:21:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-11 13:21:09 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-11 13:21:11 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-11 13:21:22 --> 404 Page Not Found: Asset/css
