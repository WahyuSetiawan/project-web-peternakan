<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-05 21:47:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-05 21:47:46 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
