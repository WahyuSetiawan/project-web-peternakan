<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-09 07:13:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 07:13:34 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-09 07:13:49 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 07:14:56 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 07:15:04 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:16:13 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:16:19 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:36:49 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:52:51 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:53:50 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:56:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 08:57:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 08:58:05 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-09 08:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-09 08:58:09 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 08:59:19 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:06:22 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 09:07:19 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:11:54 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:12:06 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:12:07 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:12:12 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:12:23 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:12:24 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:12:30 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 09:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 09:28:29 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:28:36 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:28:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 09:28:40 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:28:40 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:28:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 09:55:35 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:55:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 09:55:41 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 09:55:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 12:14:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 12:14:14 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-09 12:14:22 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 12:14:27 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 12:14:28 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 12:15:25 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 12:16:41 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 12:16:48 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 12:25:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 12:55:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 13:01:09 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:12:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 13:31:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 13:31:33 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:31:43 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:31:44 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 13:31:50 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 13:34:49 --> Severity: Notice --> Undefined variable: date0 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 154
ERROR - 2019-07-09 13:34:49 --> Severity: Notice --> Undefined variable: date0 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 154
ERROR - 2019-07-09 13:37:44 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-09 13:37:44 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-09 13:37:45 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:37:56 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:38:01 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:38:03 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:38:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 13:38:29 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-09 13:38:38 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-09 13:38:46 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:39:06 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:39:14 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:39:31 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:39:42 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:41:57 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-09 13:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 13:45:08 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 21:26:54 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-09 21:26:54 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-09 21:26:54 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-09 21:27:43 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-09 22:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-09 22:10:45 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
