<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-07 22:10:10 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
