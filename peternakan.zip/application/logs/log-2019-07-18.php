<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-18 10:04:37 --> Severity: Warning --> mysqli::real_connect(): (42000/1049): Unknown database 'peternakan_app' /usr/share/httpd/www/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-07-18 10:04:37 --> Unable to connect to the database
ERROR - 2019-07-18 10:04:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 10:06:31 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-18 10:13:12 --> Severity: Error --> Call to undefined method CI_Form_validation::ru() /usr/share/httpd/www/application/controllers/Kandang.php 30
ERROR - 2019-07-18 10:13:20 --> Severity: Error --> Call to undefined function validation_erros() /usr/share/httpd/www/application/controllers/Kandang.php 31
ERROR - 2019-07-18 10:16:42 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ')' /usr/share/httpd/www/application/cache/views/f5a8e556cd220818c5a38bf4b745d89b 9
ERROR - 2019-07-18 10:16:49 --> Severity: Parsing Error --> syntax error, unexpected ';' /usr/share/httpd/www/application/cache/views/f5a8e556cd220818c5a38bf4b745d89b 9
ERROR - 2019-07-18 10:22:49 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /usr/share/httpd/www/application/cache/views/f5a8e556cd220818c5a38bf4b745d89b 15
ERROR - 2019-07-18 10:30:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 10:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 10:43:23 --> Query error: Table 'peternakan_app.view_kandang_penjualan_avaiable' doesn't exist - Invalid query: SELECT *
FROM `view_kandang_penjualan_avaiable`
WHERE `id_detail_pembelian_ayam` = 'MA_0021'
ERROR - 2019-07-18 11:10:39 --> Severity: Notice --> Undefined variable: date11 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:10:39 --> Severity: Notice --> Undefined variable: date01 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:11:02 --> Severity: Notice --> Undefined variable: date11 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:11:02 --> Severity: Notice --> Undefined variable: date01 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:11:22 --> Severity: Notice --> Undefined variable: date11 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:11:22 --> Severity: Notice --> Undefined variable: date01 /usr/share/httpd/www/application/cache/views/d3baa3a716411bf7a60e958f92a8792f 158
ERROR - 2019-07-18 11:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 22:35:13 --> 404 Page Not Found: Faviconico/index
