<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-06 00:05:40 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-06 07:21:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 07:21:27 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-06 08:38:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:26:26 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-06 11:26:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:26:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:28:38 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-06 11:29:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:31:59 --> Severity: Notice --> Undefined variable: data_jadwal /usr/share/httpd/www/application/controllers/Gudang.php 629
ERROR - 2019-07-06 11:41:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:41:51 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-06 11:42:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:46:18 --> Severity: Notice --> Undefined property: stdClass::$id_jadwal_kadang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 208
ERROR - 2019-07-06 11:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:46:54 --> Severity: Notice --> Undefined property: stdClass::$id_jadwal_kadang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 213
ERROR - 2019-07-06 11:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 11:47:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 20:33:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 20:33:00 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-06 20:33:19 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-06 20:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-06 20:33:23 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-06 20:55:34 --> Severity: Notice --> Undefined property: Gudang::$JadwalKandangModel /usr/share/httpd/www/application/controllers/Gudang.php 473
ERROR - 2019-07-06 20:55:34 --> Severity: Error --> Call to a member function get() on a non-object /usr/share/httpd/www/application/controllers/Gudang.php 473
ERROR - 2019-07-06 21:12:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 21:19:56 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 501
ERROR - 2019-07-06 21:19:56 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 502
ERROR - 2019-07-06 21:20:41 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 501
ERROR - 2019-07-06 21:20:41 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 502
ERROR - 2019-07-06 21:20:58 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 503
ERROR - 2019-07-06 21:20:58 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 504
ERROR - 2019-07-06 21:21:50 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 503
ERROR - 2019-07-06 21:21:50 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 504
ERROR - 2019-07-06 22:31:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 22:31:09 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-06 22:31:19 --> Severity: Notice --> Undefined variable: supplier /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-06 22:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/53c206d84cb1fcae15dfd75f48baf7ad 90
ERROR - 2019-07-06 22:32:58 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:33:39 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:33:40 --> 404 Page Not Found: Asset/css
ERROR - 2019-07-06 22:42:09 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:42:20 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 22:51:47 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:53:17 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:53:48 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:55:02 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:56:12 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:56:41 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:56:49 --> Severity: Notice --> Undefined property: stdClass::$id_jadwal_kandang /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 149
ERROR - 2019-07-06 22:56:49 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:57:16 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 361
ERROR - 2019-07-06 22:58:12 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 349
ERROR - 2019-07-06 22:58:37 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:32:54 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:32:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 23:33:00 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:34:47 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:35:00 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:35:48 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:37:22 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:38:26 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:39:25 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:39:49 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:40:13 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:40:37 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:40:57 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:41:52 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
ERROR - 2019-07-06 23:43:55 --> Severity: Notice --> Undefined variable: current_date_view_target /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 364
