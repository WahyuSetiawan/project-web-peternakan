<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-19 00:41:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-19 00:41:07 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-19 00:42:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-19 00:42:24 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
ERROR - 2019-07-19 00:48:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-19 00:51:13 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 210
ERROR - 2019-07-19 01:10:10 --> Severity: Notice --> Undefined property: Gudang::$detailPenggunanGudangModel /usr/share/httpd/www/application/controllers/Gudang.php 503
ERROR - 2019-07-19 01:10:10 --> Severity: Error --> Call to a member function stokGudang() on a non-object /usr/share/httpd/www/application/controllers/Gudang.php 503
ERROR - 2019-07-19 01:10:23 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/models/DetailPenggunaanGudangModel.php 84
ERROR - 2019-07-19 01:10:59 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/models/DetailPenggunaanGudangModel.php 86
ERROR - 2019-07-19 01:11:16 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/models/DetailPenggunaanGudangModel.php 86
ERROR - 2019-07-19 01:12:21 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/models/DetailPenggunaanGudangModel.php 86
ERROR - 2019-07-19 01:12:45 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/controllers/Gudang.php 508
ERROR - 2019-07-19 01:12:45 --> Severity: Notice --> Trying to get property of non-object /usr/share/httpd/www/application/models/DetailPenggunaanGudangModel.php 86
ERROR - 2019-07-19 01:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 138
ERROR - 2019-07-19 01:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 138
ERROR - 2019-07-19 01:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() /usr/share/httpd/www/application/cache/views/16b1540958a4c1e068af670c71d06fe5 143
ERROR - 2019-07-19 01:46:50 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-19 01:46:50 --> 404 Page Not Found: Asset/vendor
ERROR - 2019-07-19 01:46:51 --> Severity: error --> Exception: Unable to locate the model you have specified: DetailPersediaanModel /usr/share/httpd/www/system/core/Loader.php 344
